(function(){Count = new Mongo.Collection('count');

})();
